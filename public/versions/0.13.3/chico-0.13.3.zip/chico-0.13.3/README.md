Chico UI
========

http://chico-ui.com.ar

Get things done, quickly
------------------------
Chico UI is a free and open source collection of easy-to-use web tools for developers and designers.

Features
-------------
- UI Widgets
- Chico Mesh: Fast and simple layouts

Get in touch
------------
- e-mail: chico (at) mercadolibre.com
- Twitter: @chicoui
- IRC: irc.freenode.net, room: #chicoui
- Google group: http://groups.google.com/group/chico-ui
- Ninja Blog: http://blog.chico-ui.com.ar/

The team
--------
- Hernan Mammana (Frontender), @hmammana
- Leandro Linares (Frontender), @lean8086
- Guillermo Paz (Frontender), @pazguille

Thanks to
---------
- Natan Santolo (@natos). Creator and former leader, now traveling around the world, drinking beer and looking for the secret of eternal life.
- Natalia Devalle (UX Designer), @taly

Credits
-------
![MercadoLibre](http://static.mlstatic.com/org-img/chico/img/logo-mercadolibre.png)

License
-------
http://chico-ui.com.ar/license
